﻿"use strict";

KTUtil.onDOMContentLoaded((function () {
	KTSigninGeneral.init()

	//e.removeAttribute("data-kt-indicator"), e.disabled = !1, Swal.fire({
	//	text: "You have successfully logged in!",
	//	icon: "success",
	//	buttonsStyling: !1,
	//	confirmButtonText: "Ok, got it!",
	//	customClass: {
	//		confirmButton: "btn btn-primary"
	//	}
	//}).then((function (e) {
	//	e.isConfirmed && (t.querySelector('[name="UserName"]').value = "", t.querySelector('[name="Password"]').value = "")
	//}))

}));